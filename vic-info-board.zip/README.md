# VIC Info Board - 自動資料更新專案

此專案會每 10 分鐘從金門港官網擷取即時船班資料，並輸出至 `/data/ferry.json`。
預期未來也會擴展支援 `/data/bus.json` 等格式，供 Fly.io 等看板部署站點使用。